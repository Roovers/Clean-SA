package test;

import IU.interfaz;
import domain.Conexion;

public class main {
    public static void main(String[] args) {
        interfaz pant1allaPrincipal = new interfaz();
    }
}
